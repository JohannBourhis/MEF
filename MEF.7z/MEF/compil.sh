gcc calElmt.c int.c maille.c testTP2b.c impcalel.c alloctab.c freetab.c -lm
