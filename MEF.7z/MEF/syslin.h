int LecSMO(int *NbLign, float **MatriceO, int **AdPrCoefLiO,
            int **NumColO, float **SecMembreO);

int dSMDaSMO(int *NbLign, float *SecMembreO, int *AdPrCoefLiO,
              float *MatriceO, int *NumColO);

